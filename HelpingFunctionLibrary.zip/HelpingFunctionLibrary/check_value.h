#pragma once


#include <iostream>
#include <string>

int play_game(int target_value);
