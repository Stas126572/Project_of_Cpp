#include <iostream>
#include <fstream>
#include <string>

int AppendHightScore(const std::string high_scores_filename, int attempts_count, const std::string user_name);
int InputHightScore(const std::string high_scores_filename);