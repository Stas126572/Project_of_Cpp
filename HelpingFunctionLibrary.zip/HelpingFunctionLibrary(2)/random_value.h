#include <iostream>
#include <cstdlib>
#include <ctime>
int get_value();
int get_value(int max_value);