#pragma once


#include <iostream>
#include <string>

int Ot(int target_value);
